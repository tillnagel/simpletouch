/**
 * SimpleTouch is a simple library to manipulate objects by touch.
 *
 * Copyright 2011
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author		Till Nagel, FH Potsdam
 * @modified	05/03/2011
 * @version		0.1.1
 */

package de.fhpotsdam.simpletouch;

import java.util.ArrayList;
import java.util.List;

import processing.core.PApplet;
import processing.core.PFont;
import TUIO.TuioClient;
import TUIO.TuioCursor;
import TUIO.TuioListener;
import TUIO.TuioObject;
import TUIO.TuioTime;

public class SimpleTouch implements TuioListener {

	protected PApplet p;

	protected TuioClient tuioClient;

	protected List<TouchObject> touchObjects = new ArrayList<TouchObject>();

	private PFont font;

	/**
	 * Creates the SimpleTouch library.
	 * 
	 * @param p
	 *            The Processing applet.
	 */
	public SimpleTouch(PApplet p) {
		this(p, null);
	}

	/**
	 * Creates the SimpleTouch library with the provided tuioClient.
	 * 
	 * @param p
	 *            The Processing applet.
	 * @param tuioClient
	 *            The TUIO client. Must be connected, already.
	 */
	public SimpleTouch(PApplet p, TuioClient tuioClient) {
		this.p = p;

		// Create or set tuioClient
		if (tuioClient == null) {
			this.tuioClient = new TuioClient();
			this.tuioClient.connect();
		} else {
			this.tuioClient = tuioClient;
		}
		// Add this as listener
		this.tuioClient.addTuioListener(this);

		// To disconnect tuioClient after applet stops
		p.registerDispose(this);
	}

	/**
	 * Gets the TuioClient, connected to this SimpleTouch.
	 * 
	 * @return The TuioClient.
	 */
	public TuioClient getTuioClient() {
		return tuioClient;
	}

	public void dispose() {
		tuioClient.disconnect();
	}

	/**
	 * Draws all TouchObjects with their current transformations.
	 */
	public void draw() {
		synchronized (touchObjects) {
			for (TouchObject transObject : touchObjects) {
				transObject.draw();
			}
		}
	}

	/**
	 * Adds a TouchObject, so it can be manipulated by finger interactions.
	 * 
	 * @param touchObject
	 */
	public void addTouchObject(TouchObject touchObject) {
		synchronized (touchObjects) {
			touchObjects.add(touchObject);
		}
	}

	public List<TouchObject> getTouchObjects() {
		return touchObjects;
	}

	public void addTuioCursor(TuioCursor tcur) {

		// Tapping is handled here (and not in TouchObject), as list re-ordering is
		// needed.

		// List is drawn from beginning (low) to end (top).
		// Topmost hit will be put topmost overall. If none was hit, list order does not change.

		TouchObject hitObject = null;
		// Hit test iterates from end to beginning, with the first hit returned.
		for (int i = touchObjects.size() - 1; i >= 0; i--) {
			TouchObject ttObj = touchObjects.get(i);
			if (ttObj.isHit(tcur.getScreenX(p.width), tcur.getScreenY(p.height))) {
				ttObj.addTuioCursor(tcur);
				hitObject = ttObj;
				break;
			}
		}

		// Put hit object to end of list, so it will be the topmost.
		synchronized (touchObjects) {
			if (hitObject != null) {
				touchObjects.remove(hitObject);
				touchObjects.add(hitObject);
			}
		}
	}

	public void removeTuioCursor(TuioCursor tcur) {
		// Pass trough remove-event to all objects, to allow fingerUp also out of boundaries,
		// as objects decide themselves (via cursor-id) whether cursor belongs to it.
		for (TouchObject ttObj : touchObjects) {
			ttObj.removeTuioCursor(tcur);
		}
	}

	public void updateTuioCursor(TuioCursor tcur) {
		// Updates go to all hit ones, independent of z-index
		for (TouchObject ttObj : touchObjects) {
			if (ttObj.isHit(tcur.getScreenX(p.width), tcur.getScreenY(p.height))) {
				ttObj.updateTuioCursor(tcur);
			}
		}
	}

	/**
	 * Draws all TuioCursors for debug purposes.
	 */
	public void drawCursors() {
		for (TuioCursor tuioCursor : tuioClient.getTuioCursors()) {
			drawCursor(tuioCursor);
		}
	}

	/**
	 * Draws a TuioCursor as small circle with ID as label. For debug purposes.
	 * 
	 * @param tc
	 *            The cursor to draw.
	 */
	public void drawCursor(TuioCursor tc) {
		if (tc == null)
			return;

		if (font == null) {
			// Load font first time a cursor was drawn
			font = p.loadFont("ml.vlw");
		}

		p.stroke(50, 100);
		p.fill(230, 150);
		p.ellipse(tc.getScreenX(p.width), tc.getScreenY(p.height), 15, 15);
		p.fill(10);
		p.textFont(font);
		p.textSize(12);
		p.text(tc.getCursorID(), tc.getScreenX(p.width) - 3, tc.getScreenY(p.height) + 4);
	}

	@Override
	public void addTuioObject(TuioObject arg0) {
	}

	@Override
	public void refresh(TuioTime arg0) {
	}

	@Override
	public void removeTuioObject(TuioObject arg0) {
	}

	@Override
	public void updateTuioObject(TuioObject arg0) {
	}
}
